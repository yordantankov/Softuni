from collections import deque
from unittest import TestCase,main
from project.railway_station import RailwayStation


class TestRailwayStation(TestCase):

    def setUp(self):
        self.station = RailwayStation("Sofia")

    def test_innit(self):
        self.assertEqual(self.station.name,"Sofia")
        self.assertEqual(self.station.arrival_trains,deque([]))
        self.assertEqual(self.station.departure_trains,deque([]))

    def test_name_setter_error(self):
        with self.assertRaises(ValueError) as va:
            self.station.name = "va"
        self.assertEqual("Name should be more than 3 symbols!",str(va.exception))

    def test_new_arrival_on_board(self):
        self.station.new_arrival_on_board("Lokomotiv")
        self.assertEqual(self.station.arrival_trains,deque(["Lokomotiv"]))

        self.station.new_arrival_on_board("Ludogorec")
        self.assertEqual(self.station.arrival_trains, deque(["Lokomotiv", "Ludogorec"]))

    def test_train_has_arrived_Before(self):
        self.station.new_arrival_on_board("Lokomotiv")
        self.station.new_arrival_on_board("Ludogorec")
        result = self.station.train_has_arrived("Ludogorec")
        self.assertEqual("There are other trains to arrive before Ludogorec.",result)

    def test_train_has_arrived_will_leave(self): #moje da probvame posle i s 2 vlaka ako ne e 100
        self.station.new_arrival_on_board("Lokomotiv")
        self.assertEqual(self.station.arrival_trains, deque(["Lokomotiv"]))
        self.assertEqual(self.station.departure_trains, deque([]))

        result = self.station.train_has_arrived("Lokomotiv")

        self.assertEqual("Lokomotiv is on the platform and will leave in 5 minutes.",result)
        self.assertEqual(self.station.arrival_trains,deque([]))
        self.assertEqual(self.station.departure_trains,deque(["Lokomotiv"]))

    def test_has_left_is_true(self):
        self.station.departure_trains = deque(["Lokomotiv"])
        result = self.station.train_has_left("Lokomotiv")
        self.assertTrue(result)
        self.assertEqual(self.station.departure_trains,deque([]))

        self.station.departure_trains = deque(["Lokomotiv","Ludogorec"])
        result = self.station.train_has_left("Lokomotiv")
        self.assertTrue(result)
        self.assertEqual(self.station.departure_trains,deque(["Ludogorec"]))


    def test_has_left_is_false(self):
        result = self.station.train_has_left("Lokomotiv")
        self.assertFalse(result)

        self.station.departure_trains = deque(["Lokomotiv", "Ludogorec"])
        result = self.station.train_has_left("Ludogorec")
        self.assertFalse(result)
        self.assertEqual(self.station.departure_trains, deque(["Lokomotiv", "Ludogorec"]))


if __name__ == "__main__":
    main()